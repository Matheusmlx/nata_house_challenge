import Styled from 'styled-components'

export const Main = Styled.div`
  width: 99vw;
  height: 110vh;
  background: #1d1928;
`;